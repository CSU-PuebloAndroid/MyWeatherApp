package com.weather.myweatherapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class airQuality extends AppCompatActivity {

    String ZIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_air_quality);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent1 = getIntent();
        ZIP = intent1.getStringExtra("zip_code");


        WebView webView = (WebView) findViewById(R.id.webview);
        webView.setWebViewClient(new Airgov());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://www.epa.gov/cgi-bin/widget.cgi?" + ZIP);
    }

    public class Airgov extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
    }
}